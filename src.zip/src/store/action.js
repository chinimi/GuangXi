/*
* vuex-actions
* */
/*保存地图map为全局变量*/
export  default {
  SaveMap(state,map){//2：传输全局变量
    state.map=map

  }


}
